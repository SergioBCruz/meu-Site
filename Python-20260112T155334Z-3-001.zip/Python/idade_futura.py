nome = input("Qual é seu nome? ")
idade = int(input("Qual sua idade atual? "))

idade_futura = idade + 5

print("Olá", nome)
print("Daqui a 5 anos você terá", idade_futura, "anos.")