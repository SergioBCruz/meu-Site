senha = "1234"

while senha != "1234":
    senha = input("Digite a senha: ")

print("Acesso liberado")
