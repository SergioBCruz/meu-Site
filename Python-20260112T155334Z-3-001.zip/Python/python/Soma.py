soma = 0
for i in range(1, 101):
    soma += i
print("Soma:", soma)