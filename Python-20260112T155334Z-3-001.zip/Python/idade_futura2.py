nome = input("Qual é seu nome? ")
idade = int(input("Qual sua idade atual? "))
ano_atual= int(input("Qual ano estamos? "))
idade_futura = idade + 10
ano_atual = 2026 
ano_futuro = ano_atual + 10

print(nome)
print("em", ano_futuro, "você tera", idade_futura, "anos ")

